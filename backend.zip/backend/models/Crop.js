const mongoose = require("mongoose");

const cropSchema = new mongoose.Schema({
  farmer_id: { type: mongoose.Schema.Types.ObjectId, ref: "Farmer", required: true },
  crop_name: { type: String, required: true },
  quantity: { type: Number, required: true },
  price: { type: Number, required: true },
  harvest_date: { type: Date },
  organic: { type: Boolean, default: false },
  image_url: { type: String },
  status: { type: String, enum: ["available", "sold_out", "expired"], default: "available" },
}, { timestamps: true });

module.exports = mongoose.model("Crop", cropSchema);