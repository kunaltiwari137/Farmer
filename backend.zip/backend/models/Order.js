const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema({
  crop_id: { type: mongoose.Schema.Types.ObjectId, ref: "Crop", required: true },
  buyer_id: { type: mongoose.Schema.Types.ObjectId, ref: "Buyer", required: true },
  quantity: { type: Number, required: true },
  total_amount: { type: Number, required: true },
  status: { type: String, enum: ["pending", "confirmed", "shipped", "delivered", "cancelled"], default: "pending" },
}, { timestamps: true });

module.exports = mongoose.model("Order", orderSchema);
