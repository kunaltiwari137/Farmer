// STEP 1: Bring in the database pool so this file can run queries
const pool = require("../config/db");
const cloudinary = require("../config/cloudinary");

// STEP 2: Create and export an async function called getAllCrops
exports.getAllCrops = async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM crops WHERE status = 'available'");
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch crops" });
  }
};

exports.createCrop = async (req, res) => {
  try {
    const { crop_name, quantity, price, harvest_date, organic, image_url } = req.body;

    if (!crop_name || !quantity || !price) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const [farmerRows] = await pool.query(
      "SELECT farmer_id FROM farmers WHERE user_id = ?",
      [req.user.user_id]
    );

    if (farmerRows.length === 0) {
      return res.status(403).json({ error: "Only registered farmers can list crops" });
    }

    const farmer_id = farmerRows[0].farmer_id;

    const [result] = await pool.query(
      `INSERT INTO crops (farmer_id, crop_name, quantity, price, harvest_date, organic, image_url)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [farmer_id, crop_name, quantity, price, harvest_date || null, organic || false, image_url || null]
    );

    res.status(201).json({ message: "Crop listed successfully", crop_id: result.insertId });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to create crop" });
  }
};

exports.getCropById = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query("SELECT * FROM crops WHERE crop_id = ?", [id]);

    if (rows.length === 0) {
      return res.status(404).json({ error: "Crop not found" });
    }

    res.json(rows[0]);

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch crop" });
  }
};

exports.updateCrop = async (req, res) => {
  try {
    const { id } = req.params;
    const { crop_name, quantity, price, harvest_date, organic, image_url, status } = req.body;

    const [existing] = await pool.query("SELECT * FROM crops WHERE crop_id = ?", [id]);
    if (existing.length === 0) {
      return res.status(404).json({ error: "Crop not found" });
    }

    const [farmerRows] = await pool.query("SELECT farmer_id FROM farmers WHERE user_id = ?", [req.user.user_id]);
    if (farmerRows.length === 0) {
      return res.status(403).json({ error: "Only registered farmers can update crops" });
    }

    if (existing[0].farmer_id !== farmerRows[0].farmer_id) {
      return res.status(403).json({ error: "You can only update your own crops" });
    }

    await pool.query(
      `UPDATE crops SET crop_name = ?, quantity = ?, price = ?, harvest_date = ?, organic = ?, image_url = ?, status = ?
       WHERE crop_id = ?`,
      [
        crop_name || existing[0].crop_name,
        quantity || existing[0].quantity,
        price || existing[0].price,
        harvest_date || existing[0].harvest_date,
        organic !== undefined ? organic : existing[0].organic,
        image_url || existing[0].image_url,
        status || existing[0].status,
        id
      ]
    );

    res.json({ message: "Crop updated successfully" });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to update crop" });
  }
};

exports.deleteCrop = async (req, res) => {
  try {
    const { id } = req.params;

    const [existing] = await pool.query("SELECT * FROM crops WHERE crop_id = ?", [id]);
    if (existing.length === 0) {
      return res.status(404).json({ error: "Crop not found" });
    }

    const [farmerRows] = await pool.query("SELECT farmer_id FROM farmers WHERE user_id = ?", [req.user.user_id]);
    if (farmerRows.length === 0 || existing[0].farmer_id !== farmerRows[0].farmer_id) {
      return res.status(403).json({ error: "You can only delete your own crops" });
    }

    await pool.query("DELETE FROM crops WHERE crop_id = ?", [id]);

    res.json({ message: "Crop deleted successfully" });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to delete crop" });
  }
};

// STEP 3: Uploads an image buffer to Cloudinary and returns the resulting URL
exports.uploadCropImage = async (req, res) => {
  try {
    // STEP 4: Multer attaches the uploaded file to req.file
    if (!req.file) {
      return res.status(400).json({ error: "No image file provided" });
    }

    // STEP 5: Cloudinary's upload function needs a stream, so we wrap it in a Promise
    const uploadFromBuffer = () => {
      return new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(
          { folder: "agriconnect_crops" },
          (error, result) => {
            if (result) resolve(result);
            else reject(error);
          }
        );
        stream.end(req.file.buffer);
      });
    };

    const result = await uploadFromBuffer();

    // STEP 6: Send back the final image URL
    res.json({ image_url: result.secure_url });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Image upload failed" });
  }
};