const multer = require("multer");

// STEP 1: Store the uploaded file temporarily in memory (as a buffer), not on disk
// We don't need to save it locally since it's going straight to Cloudinary
const storage = multer.memoryStorage();

// STEP 2: Only accept image files, reject anything else, and cap file size
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"), false);
    }
  },
});

module.exports = upload;